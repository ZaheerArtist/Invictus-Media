Working on official webiste for AI platform
